﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            // this is how we write comments
            Console.WriteLine("Hello and welcome to the C# course");

            Console.ReadLine();
        }
    }
}
