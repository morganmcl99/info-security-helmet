﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab05
{
    class Program
    {
        static void Main(string[] args)
        {

            Lab5 lab5 = new Lab5();
            //lab5.Grades();
            lab5.Part2();
            
        }
    }
}
