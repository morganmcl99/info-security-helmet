﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab05
{
    class Lab5
    {
        public void Grades()
        {
            int mark = GetInt("Please enter an exam mark: ");
            Console.ReadKey();
            //stops terminal window instantly exiting
            if ((mark < 1) || (mark > 100))
            {
                Console.WriteLine("Error: marks must be between 1..100");
                return;
            }

            if (mark > 70)
            {
                Console.WriteLine("Distinction");
            }
            else if (mark > 60)
            {
                Console.WriteLine("Merit");
            }
            else if (mark > 49)
            {
                Console.WriteLine("Pass");
            }
            else
            {
                Console.WriteLine("Fail");
            }
        }  // end of Grades


        public void Part2()
        {

            bool isSummer = GetString("Is it SummerTime, answer 'yes' or 'no'").Equals("yes");
            bool isEarlyEvening = GetString("Is it Early Evening, answer 'yes' or 'no'").Equals("yes");

            if (isSummer)
            {
                Console.WriteLine("Do outdoor hobby");
                if (isEarlyEvening)
                {
                    Console.WriteLine("Eat outside");
                }
                else
                {
                    Console.WriteLine("Eat Inside");
                }
            }
            else
            {
                Console.WriteLine("Eat Inside");
                if (isEarlyEvening)
                {
                    Console.WriteLine("Go for a walk");
                }
            }

            Console.WriteLine("Contact Friends");
            Console.WriteLine("Take a shower");
            Console.ReadKey();
        } // end of Part2



        public int GetInt(string prompt)
        {
            Console.WriteLine(prompt);
            int result = int.Parse(Console.ReadLine());
            return result;
        }

        public string GetString(string prompt)
        {
            Console.WriteLine(prompt);

            return Console.ReadLine();
            Console.ReadKey();
        }

    } // end of Lab5

}
