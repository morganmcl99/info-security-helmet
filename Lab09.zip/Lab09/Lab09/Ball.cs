﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab09
{
    public class Ball
    {

        public int x, y, w, h;
        private int dirX, dirY;

        public Ball(int x, int y, int w, int h, int dirX, int dirY) 
        {
            this.dirX = dirX;
            this.dirY = dirY;
        }

        public Ball(int x, int y, int w, int h) :this(x,y,w,h,5,5)
        {
            this.x = x;
            this.y = y;
            this.w = w;
            this.h = h;
        }

        public void move()
        {
            x += dirX;
            y += dirY;

            if (x < 10)
            {
                x = 10;
                dirX = -dirX;
            }

            if (y < 20)
            {
                y = 20;
                dirY = -dirY;
            }

            if (x > (600 - w))
            {
                x = 600 - w;
                dirX = -dirX;
            }

            if (y > (400 - h))
            {
                y = 400 - h;
                dirY = -dirY;
            }

        }


    }
}
