﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab09
{
    public partial class Form1 : Form
    {
        Ball[] balls;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(Color.Gray);
            e.Graphics.FillRectangle(Brushes.Red, 10, 10, 600, 400);
            foreach (var b in balls)
            {
                b.move();
                e.Graphics.DrawEllipse(Pens.Yellow, b.x, b.y, b.w, b.h);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            balls = new Ball[3];


            balls[0] = new Ball(15, 15, 50, 50);
            balls[1] = new Ball(20, 20, 150, 150);
            balls[2] = new Ball(10, 10, 200, 200);
            
            Timer t = new Timer();
            t.Interval = 50;
            t.Tick += T_Tick;
            t.Start();
        }

        private void T_Tick(object sender, EventArgs e)
        {
            this.Invalidate();
        }
    }
}
