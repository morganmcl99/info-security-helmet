﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab07
{
    class Lab7
    {

        public void Start()
        {
            int[] numbers = { 1, 4, -5, 7, 0, 4, 6, 8 };

            Console.WriteLine($"The sum of the numbers is {sum(numbers)}");
            Console.WriteLine($"The average of the numbers is {average(numbers)}");
            Console.WriteLine($"The minimum number is {Min(numbers)}");
            Console.WriteLine($"The maximum number is {Max(numbers)}");

            if (FindZero(numbers) < 0)
            {
                Console.WriteLine("Zero is not in the array");
            }
            else
            {
                Console.WriteLine($"The first occurence of zero is at index {FindZero(numbers)} ");
            }

            Sort(numbers);

            foreach (var item in numbers)
            {
                Console.Write($"{item}\t");
            }
            Console.WriteLine();

        } // end of start

        private int sum(int[] nos)
        {
            int sum = 0;
            foreach (var item in nos)
            {
                sum += item;
            }
            return sum;
        }

        private int average(int[] nos)
        {
            int NumberOfNums = nos.Length;
            return sum(nos) / NumberOfNums;
        }

        private int Min(int[] nos)
        {
            int min = nos[0];
            foreach (var item in nos)
            {
                if (item < min)
                {
                    min = item;
                }
            }
            return min;
        }

        private int Max(int[] nos)
        {
            int max = nos[0];
            foreach (var item in nos)
            {
                if (item > max)
                {
                    max = item;
                }
            }
            return max;
        }

        private int FindZero(int[] nos)
        {
            int index = -1;

            for (int i = 0; i < nos.Length; i++)
            {
                if (nos[i] == 0)
                {
                    index = i;
                    break;
                }
            }
            return index;
        }

        private void Sort(int[] arr)
        {
            int n = arr.Length;
            for (int i = 0; i < n - 1; i++)
                for (int j = 0; j < n - i - 1; j++)
                    if (arr[j] > arr[j + 1])
                    {
                        // swap temp and arr[i] 
                        int temp = arr[j];
                        arr[j] = arr[j + 1];
                        arr[j + 1] = temp;
                    }
        } // end of sort

    }
}
