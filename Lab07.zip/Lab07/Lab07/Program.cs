﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab07
{
    class Program
    {
        static void Main(string[] args)
        {
            Lab7 lab7 = new Lab7();

            lab7.Start();

            Console.ReadKey();
            //this read key line makes sure the terminal doesn't just disappear

        }
    }
}
