﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab10
{
    class Program
    {
        static void Main(string[] args)
        {

            string name = "Morgan";
            // so we start off with a string type variable with the value of Morgan - I will use this for the name to return using various print commands and index position parameters

            print(name[3]);
            // bearing in mind compiler factors first position as 0, 3rd position will return "g"
            print(name.ToLower());
            // converts variable 'name' value to lowercase
            print(name.ToUpper());
            // converts variable 'name' value to uppercase

            foreach (var item in name)
            {
                Console.Write($"{item}\t");
            }
            Console.WriteLine();
            Console.ReadKey();
            //makes sure terminal window doesn't just disappear when we use the Run terminal

            print(name.StartsWith("Mor"));
            print(name.EndsWith("gan"));
            print($"The index of  o in {name} is {name.IndexOf('o')}");
            print($"The index of  m in {name} is {name.IndexOf('m')}");

            StringBuilder sb = new StringBuilder("Bruce Springsteen ");
            sb.Append("is the artist ever");
            print(sb);
            sb.Insert(sb.ToString().IndexOf("artist"), "greatest ");
            print(sb);
            sb.Replace("artist", "rock star");
            print(sb);


        }
        static void print(Object x)
        {
            Console.WriteLine(x.ToString());
            // prints objects and parameters to string
            Console.ReadKey();
        }

    }
}
