﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab8
{
    class Program
    {
        static void Main(string[] args)
        {

            //Account account1 = new Account(123, "Muttley", 200);
            //print(account1.GetDetails());

            //account1.Deposit(-10);
            //print(account1.GetDetails());

            //account1.Deposit(50);
            //print(account1.GetDetails());

            //account1.Withdraw(-300);
            //print(account1.GetDetails());

            //account1.Withdraw(300);
            //print(account1.GetDetails());

            //account1.Withdraw(200);
            //print(account1.GetDetails());

            Account account2 = new Account(234, "Dick Dastardly", 100);
            print(account2.GetDetails());
            account2.AddInterest();
            print(account2.GetDetails());

            Account partnerAccount = account2;
            print(partnerAccount.GetDetails());
            partnerAccount.AddInterest();
            print(partnerAccount.GetDetails());

            ProcessAccount(account2);
            print(account2.GetDetails());

            int k = 100;
            print(k);

            IncInt(k);

            print(k);


        } // end of Main

        static void print(Object x)
        {
            Console.WriteLine(x.ToString());
        }

        static void ProcessAccount(Account acc)
        {
            acc.AddInterest();
        }

        static void IncInt(int x)
        {
            x++;
            print("x is " + x);
        }

    }
}
