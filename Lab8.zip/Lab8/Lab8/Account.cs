﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab8
{
    class Account
    {
        public int id { get; private set; }
        public string owner { get; private set; }
        private double balance;



        public Account(int id, string owner, double balance)
        {
            this.id = id;
            this.owner = owner;
            this.balance = balance;
        }

        public double Balance
        {
            get { return balance; }
            set
            {
                if (value >= 0)
                {
                    balance = value;
                }
            }
        }

        public void Deposit(double amount)
        {
            if (amount > 0)
            {
                this.balance += amount;
            }
        }

        public void Withdraw(double amount)
        {
            if ((amount >= 0) && ((balance - amount) >= 0))
            {
                this.balance -= amount;
            }
        }

        public string GetDetails()
        {
            return $"id: {this.id} owner: {this.owner} balance: {this.balance}";
        }

        public void AddInterest()
        {
            this.balance *= (1.025);
        }


    }
}
