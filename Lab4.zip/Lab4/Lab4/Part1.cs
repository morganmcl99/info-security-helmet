﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4
{
    class Part1
    {
        public int GetInt(string prompt)
        {
            Console.WriteLine(prompt);
            int result = int.Parse(Console.ReadLine());
            return result;
        }

        public string GetString(string prompt)
        {
            Console.WriteLine(prompt);

            return Console.ReadLine();


        }


        //following code is for PART 1 of LAB
        public void Part12()
        {
            
            int bag = GetInt("Price of a bag please? ");
            int money = GetInt("How much money do you have? ");
            if (money <= 0 && bag <= 0)
            {
                Console.WriteLine("Money and Price must be greater than 0");
            }
            else if (bag <= 0)
            {
                Console.WriteLine("Price must be greater than 0");
            }
            else if (money <= 0)
            {
                Console.WriteLine("Money must be greater than 0");
            }
            else
            {
                int numBag = money / bag;
                Console.WriteLine($"If the price of a bag is £{bag} and you have £{money} then you will be able to buy {numBag}.");
            }
            Console.ReadKey();
            //stops exiting
        }


}
    }
}
