﻿using System;

namespace Lab4
{
    class Program
    {
        static void Main(string[] args)
        {

            Part1 myLab4 = new Part1();
            myLab4.Part2();
            myLab4.Part12();
            
        }
        
    }
}
