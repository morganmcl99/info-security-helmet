﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab03
{
    class Program
    {
        static void Main(string[] args)
        {
            Lab3Exercises myLab3 = new Lab3Exercises();

            string name = myLab3.GetString("What is your name: ");
            int age = myLab3.GetInt("What is your age");

            Console.WriteLine($"You are {name}, you are {age} years old");


            myLab3.TheLunchQueue();

            int pounds = myLab3.GetInt("What is the total weight in pounds: ");
            myLab3.ConvertInputToStonesPounds(pounds);

            int kilos = myLab3.GetInt("What is the total weight in kilos");
            myLab3.ConvertKgsToStonesPounds(kilos);

        }
    }
}
