﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab03
{
    class Lab3Exercises
    {
        public int GetInt(string prompt)
        {
            Console.WriteLine(prompt);
            int result = int.Parse(Console.ReadLine());
            return result;
        }

        public string GetString(string prompt)
        {
            Console.WriteLine(prompt);

            return Console.ReadLine();


        }

        public void TheLunchQueue()
        {
            string mainCourse = GetString("What main dish would you like(Fish, Burgers or veg) ?");
            int potatoes = GetInt("How many roast potatos would you like?");
            int sprouts = GetInt("How many Brussel sprouts would you like?");

            string billMessage = $"Hello, your lunch is {mainCourse} with {potatoes} roast potatoes and {sprouts} Brussel sprouts.";

            Console.WriteLine(billMessage);
        }

        public void ConvertInputToStonesPounds(int pounds)
        {
            int stones = pounds / 14;
            int newPounds = pounds % 14;
            Console.WriteLine($"{pounds} lbs is {stones} stones and {newPounds} lbs");

        }

        public void ConvertKgsToStonesPounds(int kg)
        {

            int pounds = (int)(kg * 2.20462);
            int stones = pounds / 14;
            int newPounds = pounds % 14;
            Console.WriteLine($"{kg} kg is {stones} stones and {newPounds} lbs");

        }
    }
}
