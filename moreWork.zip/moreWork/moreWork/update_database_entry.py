import pyodbc 
connectionString=r'DRIVER={ODBC Driver 17 for SQL Server};SERVER=.\SQLEXPRESS;DATABASE=QAStore;Trusted_Connection=yes'
sqlStr = """ UPDATE Student
SET FirstName='Harper'
WHERE FirstName='Morgan'""" # defines which database to connect to and uses conditional WHERE filter and ORDER BY to determine output
conn = pyodbc.connect(connectionString) # initialises connection to the database above
cur = conn.cursor()
cur.execute(sqlStr) # calls the function
conn.commit()
conn.close()

#for row in result:
#	print(row)

