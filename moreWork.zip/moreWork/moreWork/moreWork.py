import pyodbc 
connectionString=r'DRIVER={ODBC Driver 17 for SQL Server};SERVER=.\SQLEXPRESS;DATABASE=QAStore;Trusted_Connection=yes'
sqlStr = " SELECT * FROM company WHERE county='London' ORDER BY company_name" # defines which database to connect to and uses conditional WHERE filter and ORDER BY to determine output
conn = pyodbc.connect(connectionString) # initialises connection to the database above
cur = conn.cursor()
result = cur.execute(sqlStr).fetchall() # calls the function
conn.close()
for row in result:
	print(row)
