package Lab7;

public class Program {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Lab7 lab7 = new Lab7();
		lab7.start();
		
	}

}
