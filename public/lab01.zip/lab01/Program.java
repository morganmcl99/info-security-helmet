package lab01;

public class Program {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hello, world!");
		System.out.println("My name is Morgan McLellan.");
	}

}
