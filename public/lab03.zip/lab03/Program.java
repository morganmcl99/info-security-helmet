// NEED TO GET CHYNNA TO REVIEW THIS - METHODS JAVA LAB
package lab03;

import java.util.Scanner;

public class Program {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
//		print(getInt("Enter an Integer"));
//		print(getString("Enter a String"));

		Lab3Exercises myLab3 = new Lab3Exercises();
		myLab3.theLunchQueue();
		int pounds = myLab3.GetInt("What is the total weight in pounds: ");
        myLab3.ConvertInputToStonesPounds(pounds);

        int kilos = myLab3.GetInt("What is the total weight in kilos");
        myLab3.ConvertKgsToStonesPounds(kilos);

	} // end of main
	
	public static int getInt(String prompt) {
		
		print(prompt);
		Scanner s = new Scanner(System.in);
		return s.nextInt();
		
	}
	
	public static String getString(String prompt) {
		
		print(prompt);
		Scanner s = new Scanner(System.in);
		return s.nextLine();
		
	}
	
	public static void print(Object x) {
		  System.out.println(x.toString());
	}
	
	
	
	public static void convertKgsToStonesPounds() {
		int kg = getInt("Enter Kilograms to convert to Stones/Pounds: ");
		double answer = kg * 0.15747;
		double pounds = kg*2.2046;
		int remainingOunces = kg % (2000*16);
		System.out.println("Hello, your lunch is %s with roast potatoes and brussels sprouts" + remainingOunces + pounds);
		
		
		
		
		
		
		
		
	}
	
	
	

}
