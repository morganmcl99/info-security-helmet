package Lab6;

import java.util.Scanner;

public class Program {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Lab6 lab6 = new Lab6(); lab6.part1();
		
		//lab6.account();
		lab6.multiplicationTable();
	}
	
	public static int getInt(String prompt) {
		
		print(prompt);
		Scanner s = new Scanner(System.in);
		return s.nextInt();
		
	}
	
	public static String getString(String prompt) {
		
		print(prompt);
		Scanner s = new Scanner(System.in);
		return s.nextLine();
		
	}
	
	public static void print(Object x) {
		  System.out.println(x.toString());
	}

}
