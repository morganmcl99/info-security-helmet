package Lab8;

public class Program {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
//		Account acc1 = new Account(123,"Dick Dastardly",1000.00);
//		
//		acc1.deposit(-100.00);
//		
//		acc1.deposit(500.00);
//		acc1.getDetails();
//		
//		acc1.withdraw(2000.00);
//		
//		acc1.withdraw(700.00);
//		acc1.getDetails();
		
		Account myAccount = new Account(234,"Muttley",100);
		myAccount.addInterest();
		
		myAccount.getDetails();
		
		Account partnerAccount = myAccount;
		
		partnerAccount.addInterest();
		
		myAccount.getDetails();
		
		processAccount(myAccount);
		myAccount.getDetails();
		
		int k = 100;
		print(k);
		incInt(k);
		print(k);
		

	} // end of main

	static void processAccount(Account acc) {
		acc.addInterest();
	}
	
	static void incInt(int x) {
		x++;
	}
	
	public static void print(Object x) {
		  System.out.println(x.toString());
	}
	
}
