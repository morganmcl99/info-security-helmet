package lab04;

import java.util.Scanner;

public class Program {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Lab4 lab4 = new Lab4(); lab4.grades(); lab4.part1();
		
		
	}
	

	public static int getInt(String prompt) {
		
		print(prompt);
		Scanner s = new Scanner(System.in);
		return s.nextInt();
		
	}
	
	public static String getString(String prompt) {
		
		print(prompt);
		Scanner s = new Scanner(System.in);
		return s.nextLine();
		
	}
	
	public static void print(Object x) {
		  System.out.println(x.toString());
	}

}
