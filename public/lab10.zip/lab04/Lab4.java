package lab04;

import java.util.Scanner;

public class Lab4 {
	
public void grades() {
		
		int mark = getInt("Please enter an exam mark: ");
		
		if(mark < 1 || mark > 100) {
			System.out.println("Error: marks must be between 1..100");
			return;
		}
		
		
		if(mark > 70) {
			System.out.println("You have a Distinction");
		}
		else if(mark > 60) {
			System.out.println("You have a Merit");
		}
		else if(mark > 49) {
			System.out.println("You have a Pass");
		}
		else {
			System.out.println("You have a Fail");
		}
				
		
	} // end of grades
	
	

	public void part1() {
		
		int bag = getInt("Price of a bag please? ");
		int money = getInt("How much money do you have? ");
		
		if (money <= 0 && bag <= 0)
        {
			System.out.println("Money and Price must be greater than 0");
        }
        else if (bag <= 0)
        {
        	System.out.println("Price must be greater than 0");
        }
        else if (money <= 0)
        {
        	System.out.println("Money must be greater than 0");
        }
        else
        {
            int numBag = money / bag;
            System.out.printf("If the price of a bag is �%s and you have �%d then you will be able to buy %d bags.",
    				bag,
    				money,
    				numBag);
        }
        
		
		

	}
	
	public int getInt(String prompt) {
		
		print(prompt);
		Scanner s = new Scanner(System.in);
		return s.nextInt();
		
	}

	public String getString(String prompt) {
		
		print(prompt);
		Scanner s = new Scanner(System.in);
		return s.nextLine();
		
	}

	 public void print(Object x) {
		  System.out.println(x.toString());
	}
	
}
