package Lab6;

import java.util.Scanner;

public class Lab6 {
	
	public int getInt(String prompt) {
		
		print(prompt); 
		Scanner s = new Scanner(System.in);
		return s.nextInt();
		
	}

	public String getString(String prompt) {
		
		print(prompt);
		Scanner s = new Scanner(System.in);
		return s.nextLine();
		
	}

	 public void print(Object x) {
		  System.out.println(x.toString());
	}

	 public void part1() {
			
			int[] marks = new int[5];
			String[] names = new String[5];
			
			for(int i = 0; i < 5; i++) {
				names[i] = getString("Enter a student's name");
				marks[i] = getInt("Enter the student's mark");
				
			}
			
			for(int i = 0; i < 5; i++) {
				System.out.printf("name: %s grade: %s mark: %d\n",
						names[i],
						grades(marks[i]),
								marks[i]);
			}
					
			
		} // end of part 1
		
		
		public String grades(int mark) {
			
					
			if(mark < 1 || mark > 100) {
				return "Error: marks must be between 1 and 100";
			}
					
			if(mark > 70) {
				return"Distinction";
			}
			else if(mark > 60) {
				return "Merit";
			}
			else if(mark > 49) {
				return "Pass";
			}
			else {
				return "Fail";
			}
					
			
		} // end of grades
		
		public void account() {
			
			double investment = 100;
			int count = 0;
			double rate = 0.05;
			
			while (investment < 200) {
				count++;
				investment *= 1 + rate;
			}
			
			System.out.printf("It would take %d years to double your money", count);
			
		} // end of account
		
		
		public void multiplicationTable() {
			
			for(int i = 1; i < 11; i++) {
				for(int j = 1; j < 11; j++) {
					System.out.printf("%5d", i*j);
				}
				System.out.println();
			}	
			
		} // end of multiplicationTable
		

		
		
		

		
	}
	

