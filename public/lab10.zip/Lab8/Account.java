package Lab8;

public class Account {
	
	private int id;
	private String owner;
	private double balance;
	
	public Account(int id, String owner, double balance) {
		this.id = id;
		this.owner = owner;
		this.balance = balance;
	}
	
	
	public void deposit(double amount) {
		
		if(amount < 0) {
			System.out.printf("You cannot deposit a negative amount %.2f\n", amount);
		}
		else {
			this.balance += amount;
		}		
	} // end of deposit
	
	public void withdraw(double amount) {
		
		if((balance - amount) < 0) {
			System.out.printf("You do have enough money to withdraw amount %.2f\n", amount);
		}
		else {
			this.balance -= amount;
		}		
	} // end of withdraw
	
	public void getDetails() {
		System.out.printf("id: %d\nOwner: %s\nBalance: %.2f\n", id,owner,balance);
	}  // end of getDetails
	
	public void addInterest() {
		this.balance *= 1.025;
	}
	
	
}
