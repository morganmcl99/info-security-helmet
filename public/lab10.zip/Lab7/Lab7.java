package Lab7;

public class Lab7 {

	public void start() {
		
		int[] numbers = {1,3,-5,7,0,4,6,8};
		
		int sum = sum(numbers);
		System.out.printf("Sum of numbers is %d\n", sum);
		double aver = average(numbers);
		System.out.printf("Average of numbers is %f\n", aver);
		int min = mini(numbers);
		System.out.printf("Minimum number in numbers is %d\n", min);
		int max = maxi(numbers);
		System.out.printf("Maximum number in numbers is %d\n", max);
		
		int ind = findIndex(numbers,0);
		System.out.printf("The index of value 0 in numbers is %d\n", ind);		
		
		int[] sorted = numbers;
		bubbleSort(sorted);
		
		for(int no : sorted) {
			System.out.printf("%d ", no);
		}
		System.out.println();
	}
	
	private int sum(int[] nos) {
		
		int total = 0;
		
		for (int no : nos) {
			total += no;
		}
		
		return total;
	} // end of sum
	
	
	private double average(int[] nos) {
		
		double avg = (double)sum(nos)/(double)nos.length;
		return avg;
		
	} // end of average
	
	private int mini(int[] nos) {
		
		int min = nos[0];
		
		for(int val : nos) {
			if(min > val) {
				min = val;
			}
		}
		return min;
	} // end of mini
	
	
	private int maxi(int[] nos) {
		
		int max = nos[0];
		
		for(int val : nos) {
			if(max < val) {
				max = val;
			}
		}
		return max;
	} // end of maxi
	
	private int findIndex(int[] nos, int value) {
		
		int index = -1;
		
		for(int i =0; i < nos.length; i++) {
			if(value == nos[i]) {
				index = i;
				break;
			}
		}
		
		return index;
		
	} // end of find index
	
	
	  void bubbleSort(int arr[]) 
	    { 
	        int n = arr.length; 
	        for (int i = 0; i < n-1; i++) 
	            for (int j = 0; j < n-i-1; j++) 
	                if (arr[j] > arr[j+1]) 
	                { 
	                    // swap arr[j+1] and arr[i] 
	                    int temp = arr[j]; 
	                    arr[j] = arr[j+1]; 
	                    arr[j+1] = temp; 
	                } 
	    } 
	
	static void print(Object... things) {
		
		  for (Object x : things)
			System.out.println(x.toString());
	}
	
	
}
