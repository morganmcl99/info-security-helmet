package lab10;

public class Program {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// Part 2 
		
		String name = "Morgan";
		
		print(name.charAt(2));
		print(name.toLowerCase());
		print(name.toUpperCase());
		
		for(char c : name.toCharArray()) {
			System.out.printf("%c\t", c);
		}
		System.out.println();
		
		print(name.startsWith("Mo"));
		print(name.startsWith("Bo"));
		
		print(name.endsWith("an"));
		print(name.endsWith("dd"));
		
		print(name.indexOf('o'));
		print(name.indexOf('z'));
		
		String fullname = name.concat(" McLellan");
		print(fullname);
		//prints full name, using concatenation
		
		// Part 3
		
		StringBuilder sb = new StringBuilder("Morgan McLellan ");
		
		sb.append("is the web designer ever");
		
		print(sb);
		// print the sb variable using StringBuilder, using the append command to add "is the web designer ever" onto the end of the initial name string
		
		sb.insert(23, "greatest ");
		// inserts the string/word greatest followed by a single space at the index position of 23 characters from the start of the returned string
		
		print(sb);
		
		int index = sb.indexOf("designer");
		
		sb.replace(index, index + 8, "developer");
		// replaces the word, taking into account the index position(s)
		
		print(sb);
		//print the desired replacement of designer for developer, using the print command to do this
		

	} // end of main
	
	public static void print(Object x) {
		  System.out.println(x.toString());
	}

}
