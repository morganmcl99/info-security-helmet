package lab03;

import java.util.Scanner;

public class Lab3Exercises {
			

 // end of main

public int getInt(String prompt) {
	
	print(prompt);
	Scanner s = new Scanner(System.in);
	return s.nextInt();
	
}

public String getString(String prompt) {
	
	print(prompt);
	Scanner s = new Scanner(System.in);
	return s.nextLine();
	
}

 public void print(Object x) {
	  System.out.println(x.toString());
}

public void theLunchQueue() {
	
	String mainCourse = getString("What main dish would you like(Fish, Burgers or Vegan)?;");
	int roasties = getInt("How many Roast Potatoes would you like?");
	int brussels = getInt("How many Brussels Sproats would you like?");
	
	System.out.printf("Hello, your lunch is %s with %d roast potatoes and %d brussels sprouts",
			mainCourse,
			roasties,
			brussels);
}

	public int GetInt(String string) {
		// TODO Auto-generated method stub
		return 0;
	}
	
	public void ConvertInputToStonesPounds(int pounds)
    {
        int stones = pounds / 14;
        int newPounds = pounds % 14;
        System.out.printf("{pounds} lbs is {stones} stones and {newPounds} lbs");

    }

    public void ConvertKgsToStonesPounds(int kg)
    {

        int pounds = (int)(kg * 2.20462);
        int stones = pounds / 14;
        int newPounds = pounds % 14;
        System.out.printf("{kg} kg is {stones} stones and {newPounds} lbs");

    }

}
