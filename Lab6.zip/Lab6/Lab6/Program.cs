﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab06
{
    class Program
        //defines the class for the C# program we are executing
    {
        static void Main(string[] args)
        {
           
            // creates a new instance and calls the relevant methods, e.g. Part1, Part2, MultiplicationTable etc.
            Lab6 lab6 = new Lab6();

            lab6.Part1();

            lab6.Part2();

            lab6.MultiplicationTable();

            Console.ReadKey();
            //this read key line makes sure the terminal doesn't just disappear
        }
    }
}
