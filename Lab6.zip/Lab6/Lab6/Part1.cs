﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab06
{
    class Lab6
    {
        public int GetInt(string prompt)
        {
            Console.WriteLine(prompt);
            int result = int.Parse(Console.ReadLine());
            return result;
        }

        public string GetString(string prompt)
        {
            Console.WriteLine(prompt);

            return Console.ReadLine();
        }

        public void Grades(int mark)
        {


            if ((mark < 1) || (mark > 100))
            {
                Console.WriteLine("Error: marks must be between 1 and 100");
                return;
            }
            // above if statement is a conditional statement - || is an OR operator rather than && being an AND operator. Returns the error line in the double speech marks above if integer input value given is less than 1 or greater than 100.

            // if mark is over 70:
            if (mark > 70)
            {
                Console.Write("Distinction\n");
            }
            // an else if statement that returns if value is over 60:
            else if (mark > 60)
            {
                Console.Write("Merit\n");
            }
            else if (mark > 49)
            {
                Console.Write("Pass\n");
            }
            else
            {
                Console.Write("Fail\n");
            }
        }  // end of Grades

        public void Part1()
        {

            // creates a string with a length of 5 values, then run for loop for the determined length (5) as set out below
            string[] names = new string[5];
            int[] marks = new int[5];

            for (int i = 0; i < names.Length; i++)
            {
                names[i] = GetString("Enter a name: ");
                marks[i] = GetInt("Enter their exam score: ");
            }

            // return each person's name and exam mark using this for loop
            for (int i = 0; i < marks.Length; i++)
            {
                Console.Write($"Name: {names[i]} Exam score: {marks[i]} ");
                Grades(marks[i]);
            }

        } // end of part1

        public void Part2()
        {

            double invest = 100;
            double rate = 0.05;

            int years = 0;

            //while loop runs as long as the above condition is true
            while (invest < 200)
            {
                // we define the increment value below:
                years++;
                // the mathematical calculation and using BODMAS to calculate it in the correct order to return the intended answer
                invest = invest + (invest * rate);
                Console.WriteLine($"Year {years} investment {invest:C}");
            }

            Console.WriteLine($"It took {years} years to grow the initial investment to over £200");
        } // end of Part2

        public void MultiplicationTable()
        {

            for (int i = 1; i < 11; i++)
            {
                for (int j = 1; j < 11; j++)
                {
                    Console.Write("{0,5}", i * j);
                }
                Console.WriteLine();
            }

        }

    }
}
