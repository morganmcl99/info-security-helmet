﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab02
{
    class Program
    {
        static void Main(string[] args)
        {
            //Hello

            //Creating variables here


            String name = "Morgan McLellan";
            int age = 23;
            int house_number = 6;
            String street = "Church Lane West";
            String post_code = "GU11 3LH";
            String telephone_number = "07493231940";
            String company = "Acas";
            double salary = 90000;
            bool driving_license = true;

            Console.WriteLine("Employee Details:");
            Console.WriteLine(name + " " + age + " lives at " + house_number + ", " + street + ", " + post_code + ", " + telephone_number + ", works at " + company + " and earns: £" + salary);

            int number = 5;
            Console.WriteLine("Initial Value: " + number);


            // Task 1
            // - double it using the '*' operator
            int newnumber = number * 2;
            Console.WriteLine("\nThe original number was " + number + ". After doubling it: " + newnumber);
            // - now double it again using the '*=' operator

            int beforenumber = newnumber;
            newnumber *= 2;

            Console.WriteLine("\n1. The original number was " + number + ". Doubled was " + beforenumber + ". After doubling it and doubling it again: " + newnumber);


            // Task 2

            // - add 3 to it using the '+' operator
            newnumber = newnumber + 3;
            // - now add 3 to it using the '+=' operator
            newnumber += 3;
            Console.WriteLine("\n2. After adding 3 twice: " + newnumber);

            // Task 3 - subtract 12 from it using an appropriate 'compound' operator

            newnumber -= 12;
            Console.WriteLine("\n3. After subtracting 12: " + newnumber);

            // Task 4 - divide the number (ought to be 14 now) by 3

            newnumber = newnumber /= 3;

            // what do you think the answer is

            Console.WriteLine("\n4. After dividing by 3: " + newnumber);

            // Task 5 write 4 different statements that all do the same thing

            // namely 'add 1 to the number'
            newnumber += 1;
            newnumber += 1;
            newnumber += 1;
            newnumber += 1;

            Console.WriteLine("\n5. After adding 1 four times: " + newnumber);

            // Task 6 decrement by 1 the value of number
            newnumber--;
            Console.WriteLine("\n6. After decrementing once: " + newnumber);

            // Task 7 put the remainder when dividing by 3 into 'remainder'

            int remainder = newnumber%3;

            Console.WriteLine("\n7. Remainder when dividing by 3 is: " + remainder);

            // Task 8

            int a = 2, b = 3, c = 5;
            double d1, d2, d3, d4;
            d1 = a + b * c / 2;
            d2 = (a + b * c) / 2;
            d3 = (a + b) * c / 2;
            d4 = (a + b) * (c / 2);

            // decide what it will print before uncommenting the Console.WriteLine()

            Console.WriteLine("\n8. Values: " + d1 + " : " + d2 + " : " + d3 + " : " + d4);

            // Type your answer here--> d1=9 (based on 9.5, only returns whole number) d2=8 (does not return 8.5, only whole number) d3=12(does not return 12.5, only whole number) d4=10

            // Task 9

            int p, q;

            p = 10;

            q = 10;

            p += q++;

            // Decide what the next line will print

            Console.WriteLine("\n9. Result is: " + (p + q)); // Answer--> 31 due to increment operator

            // Task 10 – Uncomment the code below

            Console.WriteLine("\n11.");

            // Decide what the following 4 lines will print
            // The 4th one might surprise you

            Console.WriteLine("fred" + 3 + 4); // Answer--> fred34

            Console.WriteLine(3 + 4 + "fred"); // Answer--> 7fred

            Console.WriteLine("" + 3 + 4); // Answer--> 34

            Console.WriteLine(3 + ' ' + 4); // Answer--> Single quote space equals to a value of 32, then add that to the sum of 3 and 4 added together, equals 39 (4+3+32)

            //if you run program with just F5 or by pressing start, console screen will appear and go
            //but with either Ctrl+f5 or by adding a line below, your screen will hold

            Console.ReadLine(); // to hold the screen


        }
    }
}
